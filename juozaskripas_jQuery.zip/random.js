/*
   New Perspectives on HTML and XHTML 5th Edition
   Function List:
   randomInteger()
      Used to reverse the order of characters in a text string
*/


function randomInteger(size) {
   return Math.floor((size+1)*Math.random());
}